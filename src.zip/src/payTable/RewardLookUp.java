package payTable;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import patterns.Pattern;

public class RewardLookUp {
	private List<Reward> rewards;
	public RewardLookUp(String file) throws IOException{//read paytable
		rewards = new ArrayList<Reward>();
        BufferedReader br = new BufferedReader(new FileReader(file));
        String st;double pay=0;
        while ((st = br.readLine()) != null) {
        	if (st.trim().length() > 0) {
	        	StringTokenizer tok = new StringTokenizer(st);  
	        	String[] symbols = new String[tok.countTokens()-1];
	        	int symbolIndex = 0;
			        while (tok.hasMoreTokens()) {  
			        	if(symbolIndex == symbols.length) {//last symbol
			        		String token = tok.nextToken();
			        		pay = Double.parseDouble(token);
			        	}else {
				        	String token = tok.nextToken();
				        	symbols[symbolIndex] = token;
				        	symbolIndex++;
			        	}
			        }  
			     Reward reward = new Reward(pay,symbols[0],symbols.length);
			     rewards.add(reward);
			}
    	}
	}
	public List<Reward> findRewardCombinations(String[][] symbols){
		List<Reward> matchingRewards = new ArrayList<Reward>();
		for(int i = 0; i < rewards.size(); i++) {
			Reward currentReward = rewards.get(i);
			if(currentReward.meetRequirements(symbols)) {
				matchingRewards.add(currentReward);
			}
		}
		return matchingRewards;
	}
	public boolean isRewardInPattern(Pattern pattern, Reward reward, String[][] symbols) {
		String thisSymbol = reward.getSymbol();
		if(pattern.meetsRequirements(symbols, thisSymbol)) {
			return true;
		}else {
			return false;
		}
	}
	
}
