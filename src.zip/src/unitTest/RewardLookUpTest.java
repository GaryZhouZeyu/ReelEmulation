package unitTest;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Test;

import payTable.Reward;
import payTable.RewardLookUp;

class RewardLookUpTest {

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@Test
	void test() throws IOException{
		String filePath = "C:\\Users\\Gary\\eclipse-workspace\\ReelEmulation\\Paytable.txt";
		RewardLookUp rlu = new RewardLookUp(filePath);
		String[][] symbols = {
				{"K","K","K","A","A"},
				{"Q","Q","Q","Q","Q"},
				{"A","A","A","A","J"}
			};
		
		List<Reward> matchingRewards = rlu.findRewardCombinations(symbols);
		assertEquals(7, matchingRewards.size());
		
	}

}
