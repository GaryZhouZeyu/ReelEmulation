package unitTest;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Test;

import patterns.Pattern;
import patterns.PatternLookUp;

class PatternLookUpTest {

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@Test
	void test() throws IOException{
		PatternLookUp plu = new PatternLookUp("patterns.txt");
		String symbols[][] = {
				{"K","K","K","K","K"},
				{"Q","Q","Q","Q","Q"},
				{"A","A","A","A","A"}
		};
		List<Pattern> matches;
		matches = plu.findMatchPatternCombinations(symbols);
		assertEquals(1, matches.size());
		
		
	}
	
	@Test
	void testSpecialPattern() throws IOException{
		PatternLookUp plu = new PatternLookUp("patterns.txt");
		String symbols[][] = {
				{"K","A","A","A","K"},
				{"A","K","K","K","Q"},
				{"K","A","A","A","K"}
		};
		List<Pattern> matches;
		matches = plu.findMatchPatternCombinations(symbols);
		assertEquals(0, matches.size());
		
		
	}

}
