package winnings;

import java.util.List;

import patterns.Pattern;
import patterns.PatternLookUp;
import payTable.Reward;
import payTable.RewardLookUp;

public class CheckWin {
	private String symbols[][];
	public CheckWin(String[][] symbols) {
		this.symbols = symbols;
	}
	public double calculateWin(RewardLookUp rlu, PatternLookUp plu) {
		List<Pattern> patterns = plu.findMatchPatternCombinations(symbols);
		double sumWin = 0;
		for(Pattern checkPattern : patterns) {
			List<Reward> rewards = rlu.findRewardCombinations(symbols);
			Reward highestReward = rewards.get(0);
			for(Reward checkReward : rewards) {
				if (checkReward.getAmount() > highestReward.getAmount() && rlu.isRewardInPattern(checkPattern, checkReward, symbols)) {
					highestReward = checkReward;
				}
			}
			sumWin+=highestReward.getAmount();
		}
		return sumWin;
	}
}
