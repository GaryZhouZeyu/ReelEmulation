package patterns;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import payTable.Reward;

public class PatternLookUp {
	private List<Pattern> patterns;
	

	public PatternLookUp(String file) throws IOException{//read paytable
		patterns = new ArrayList<Pattern>();
        BufferedReader br = new BufferedReader(new FileReader(file));
        String st;
        int i=0;
        while ((st = br.readLine()) != null) {
        	List<String> lines = new ArrayList<>();
        	while (st != null && st.trim().length() > 0) {
	        	lines.add(st);
	        	st  = br.readLine();	        	
			}
        	Pattern p = new Pattern(lines);
		    patterns.add(p);
    	}
	}
	public List<Pattern> findMatchPatternCombinations(String[][] symbols){
		List<Pattern> matchingPatterns = new ArrayList<Pattern>();
		//loop through the symbols in the left-most column
		for (int row = 0; row < symbols.length; row++) {
			String symbol = symbols[row][0];
			for(int i = 0; i < patterns.size(); i++) {
				Pattern currentPattern = patterns.get(i);
				if(currentPattern.meetsRequirements(symbols, symbol)) {
					matchingPatterns.add(currentPattern);
				}
			}
			
		}
		return matchingPatterns;
	}

	/*
	 * 		List<Pattern> matchingPatterns = new ArrayList<Pattern>();
		for(int i = 0; i < patterns.size(); i++) {
			Pattern currentPattern = patterns.get(i);
			if(currentPattern.meetsRequirements(symbols, thisSymbol)) {
				matchingPatterns.add(currentPattern);
			}
		}
		return matchingPatterns;
	 */
}
