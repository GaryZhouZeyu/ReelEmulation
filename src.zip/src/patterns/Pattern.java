package patterns;

import java.util.List;

public class Pattern {
	private boolean pattern[][];
	public static final int REELNUM = 5;
	public Pattern(List<String> patternLines){
		//read pattern text
		pattern = new boolean[patternLines.size()][];
		for(int row = 0; row < patternLines.size(); row++) {
			pattern[row] = new boolean[REELNUM];
			for(int reelNum = 0; reelNum < REELNUM; reelNum++) {
				String currentLine = patternLines.get(row);
				char symbol = currentLine.charAt(reelNum);
				pattern[row][reelNum] = (symbol == 'x' || symbol == 'X');				
			}
		}
	}
	
	
	public int countMatches(String[][] symbols, String thisSymbol) {
		int matchCount = 0;
		for(int row = 0; row < pattern.length; row++) {
			for(int reelNum = 0; reelNum < REELNUM; reelNum++) {
				if(pattern[row][reelNum]) {
					if(symbols[row][reelNum].equals(thisSymbol)) {
						matchCount++;
					}else {
						break; //start from left, continue without breaking
					}
				}
			}
		}
		return matchCount;
	}
	
	public boolean meetsRequirements(String[][] symbols, String thisSymbol) {
		int matchCount = countMatches(symbols,thisSymbol);
		return  matchCount== 3 || matchCount == 4 || matchCount == 5;
	}
	
}
